import argparse
import os

import torch
import torchvision
import torchvision.transforms as transforms
from PIL import Image
from model.model import *

classes = ('fresh apple', 'fresh banana', 'fresh orange', 'rotten apple', 'rotten banana', 'rotten orange')
device = "cuda" if torch.cuda.is_available() else "cpu"


def predict():
    args = parser.parse_args()

    path = args.weights
    imgdir = args.img_dir

    # model = resnet50()
    model = resnext50_32x4d()
    checkpoint = torch.load(path)
    model.load_state_dict(checkpoint["model_dict"])

    model = model.to(device)

    model.eval()

    # 预处理图片
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.226, 0.224, 0.225])
    ])

    files = os.listdir(imgdir)
    for f in files:
        # print(f)
        # 拼接路径
        real_url = imgdir + '/' + f
        # print(real_url)

        if not f.endswith('.img') and not f.endswith('.png'):
            continue

        img = Image.open(real_url)

        img = img.convert("RGB")  # If it is a standard RGB format, it can be left out
        img = transform(img)
        img = img.unsqueeze(0)
        img = img.to(device)

        with torch.no_grad():
            py = model(img)

        '''
        The torch.max() function returns two values, the first being the concrete value (which we denote by the underscore _) 
        and the second being the index at which the value is located
        The underscore _ is the concrete value, which is the maximum value of the output.
        The number 1 can actually be written as dim=1, here it is abbreviated to 1, and python will automatically recognise
         that dim=1 means the maximum value of the line where the output is located
        '''
        _, predicted = torch.max(py, 1)  # 获取分类结果
        # 预测结果的标签
        classIndex = predicted.item()

        print("Picture：", real_url, " Result：", classes[classIndex])


def predict_(img):
    args = parser.parse_args()
    path = 'results/exp1/best.pth'
    imgdir = args.img_dir
    model = resnet50()
    # model = resnext50_32x4d()
    checkpoint = torch.load(path)
    model.load_state_dict(checkpoint["model_dict"])
    model = model.to(device)
    model.eval()
    # 预处理图片
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.226, 0.224, 0.225])
    ])
    img = img.convert("RGB")
    img = transform(img)
    img = img.unsqueeze(0)
    img = img.to(device)
    with torch.no_grad():
        py = model(img)
    _, predicted = torch.max(py, 1)  # Get classification results
    # 预测结果的标签
    classIndex = predicted.item()

    return classes[classIndex]


parser = argparse.ArgumentParser(description='PyTorch fruits Predict')
parser.add_argument('--weights', default='./runs/best.pth', help='')
parser.add_argument('--img_dir', default='./val', help='')

if __name__ == '__main__':
    predict()
