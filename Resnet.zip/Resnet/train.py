import os
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import argparse
from model.model import *
from torch.utils.tensorboard import SummaryWriter

# Define if GPU is used
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Parameter setting, which allows us to enter command line parameters manually
parser = argparse.ArgumentParser(description='PyTorch Fruits Training')
parser.add_argument('--outf', default='./runs/', help='folder to output images and model checkpoints')  # 输出结果保存路径
parser.add_argument('--resume', default=False, help="path to net (to continue training)")  # 恢复训练时的模型路径
parser.add_argument('--weights', default='', help='weight file for model')
parser.add_argument('--epoch', default=20, help='the training rounds')
parser.add_argument('--batch', default=16, help='the batch size')
parser.add_argument('--lr', default=0.001, help='the learning rate')

args = parser.parse_args()

# Hyperparameter setting
EPOCH = args.epoch  # Number of times the data set was traversed
BATCH_SIZE = args.batch  # Batch size (batch_size)
LR = args.lr  # learning rate
pre_epoch = 0  # Defines the number of times the data set has been traversed


# Save model progress
def save_model(save_path, epoch, optimizer, best_acc, acc, model):
    torch.save({'epoch': epoch + 1,
                'optimizer_dict': optimizer.state_dict(),
                'model_dict': model.state_dict(),
                'best_acc': best_acc,
                'last_acc': acc},
               save_path)


# load model
def load_model(save_name, optimizer, model):
    model_data = torch.load(save_name)
    model.load_state_dict(model_data['model_dict'])
    optimizer.load_state_dict(model_data['optimizer_dict'])
    return {
        'pre_epoch': model_data['epoch'],
        'best_acc': model_data['best_acc'],
        'acc': model_data['last_acc']
    }


# Preparation and pre-processing of data sets
transform_train = transforms.Compose([
    transforms.CenterCrop(size=1024),
    transforms.Resize(224),
    transforms.RandomHorizontalFlip(),
    torchvision.transforms.ColorJitter(brightness=0.5, contrast=0, saturation=0,
                                       hue=0),
    torchvision.transforms.ColorJitter(brightness=0, contrast=0.5, saturation=0,
                                       hue=0),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

transform_test = transforms.Compose([
    transforms.CenterCrop(size=1024),
    transforms.Resize(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

trainset = torchvision.datasets.ImageFolder(root='data/train', transform=transform_train)  # 训练数据集
trainloader = torch.utils.data.DataLoader(trainset, batch_size=BATCH_SIZE, shuffle=True,
                                          num_workers=1)  # 生成一个个batch进行批训练，组成batch的时候顺序打乱取

testset = torchvision.datasets.ImageFolder(root='data/test', transform=transform_test)
testloader = torch.utils.data.DataLoader(testset, batch_size=BATCH_SIZE, shuffle=True, num_workers=1)

# labels
classes = ('fresh apple', 'fresh banana', 'fresh orange', 'rotten apple', 'rotten banana', 'rotten orange')

# Defining the model
net = resnet50(num_classes=6)

# Initialising the best accuracy variables
best_acc = 0

# Loading the last training model
if (args.resume):
    # 加载权重文件路径
    model_weight_path = "./runs/last.pth"
    assert os.path.exists(model_weight_path), "file {} does not exist.".format(model_weight_path)
    # Load weights file path
    model_data = torch.load(model_weight_path)
    # Loading models
    net.load_state_dict(model_data['model_dict'])
    net.to(device)
    # Creating optimization functions
    optimizer = torch.optim.Adam(net.parameters(), lr=LR)
    # Load optimization functions
    optimizer.load_state_dict(model_data['optimizer_dict'])
    # Load best accuracy
    best_acc = model_data['best_acc']
    pre_epoch = model_data['epoch']
else:
    net.to(device)
    # Defining optimization methods
    # Optimization is mini-batch momentum-SGD with L2 regularisation (weight decay)
    optimizer = optim.SGD(net.parameters(), lr=LR, momentum=0.09,
                          weight_decay=5e-4)

# Defining the loss function
# The loss function is cross-entropy, which is mostly used for multi-classification problems
# standard integrates LogSoftMax and NLLLoss into one class.
criterion = nn.CrossEntropyLoss()

# 4. creat writer object
writer = SummaryWriter(log_dir="./runs/tensor", flush_secs=50)

# 训练
if __name__ == "__main__":
    print("Start Training, Resnet50!")  # Define the number of times to traverse the data set
    with open(args.outf + "acc.txt", "w") as f:
        with open(args.outf + "log.txt", "w") as f2:
            for epoch in range(pre_epoch, EPOCH):  # Start training from previous times
                print('\nEpoch: %d' % (epoch + 1))  # Output current count
                # These two functions affect the parameters of both Dropout and BatchNormalization
                # applied to the network, and will affect both during training

                ''' 
                When net.train() is applied, 
                the above two parameters are adjusted accordingly at each min - batch during training
                all BatchNormalization is done differently during training and testing.
                '''
                net.train()
                sum_loss = 0.0  # Number of losses
                correct = 0.0  # Exact number
                total = 0.0  # Total number

                for i, data in enumerate(trainloader, 0):
                    # Prepare data i -> serial number data is the data element to be traversed
                    length = len(trainloader)  # Number of training sessions
                    inputs, labels = data
                    # inputs is the current input image, label is the label of the current image
                    # each sample in this data corresponds to a label
                    inputs, labels = inputs.to(device), labels.to(device)

                    optimizer.zero_grad()  # Clear the gradient of all optimized Variables

                    # forward + backward
                    outputs = net(inputs)  # Get an output after training
                    loss = criterion(outputs, labels)
                    loss.backward()
                    optimizer.step()  # Perform a single optimization (parameter update).

                    # Print loss and accuracy once for every 1 batch trained
                    sum_loss += loss.item()
                    # Returns the maximum value of all elements of the input tensor. Set the dim dimension to 1, otherwise keep it the same as the input shape.
                    _, predicted = torch.max(outputs.data, 1)
                    total += labels.size(0)
                    correct += predicted.eq(labels.data).cpu().sum()
                    writer.add_scalar('total_loss', sum_loss, epoch)
                    writer.add_scalar('total_Acc', correct / total, epoch)
                    print('\r[epoch:%d, iter:%d/%d] Loss: %.03f | Acc: %.3f%% '
                          % (epoch + 1, (i + 1), length, sum_loss / (i + 1), 100. * correct / total), end="")
                    f2.write('%03d  %05d |Loss: %.03f | Acc: %.3f%% '
                             % (epoch + 1, (i + 1 + epoch * length), sum_loss / (i + 1), 100. * correct / total))
                    f2.write('\n')
                    f2.flush()

                # Verify accuracy after each training epoch
                print("\n Waiting Test!")
                with torch.no_grad():  # No derivative
                    correct = 0
                    total = 0
                    for data in testloader:
                        net.eval()
                        images, labels = data
                        images, labels = images.to(device), labels.to(device)
                        outputs = net(images)
                        # Get the class with the highest score (index number of outputs.data)
                        _, predicted = torch.max(outputs.data, 1)
                        total += labels.size(0)
                        correct += (predicted == labels).sum()
                    print('Test classification accuracy：%.3f%%' % (100 * correct / total))
                    acc = 100. * correct / total
                    # Write the results of each test in real time to the acc.txt file
                    # torch.save(net.state_dict(), '%s/last.pth' % args.outf)
                    save_model(args.outf + '/last.pth', epoch, optimizer, best_acc, acc, net)
                    f.write("EPOCH=%03d,Accuracy= %.3f%%" % (epoch + 1, acc))
                    f.write('\n')
                    f.flush()
                    # Record the best test classification accuracy and write it in the best_acc.txt file
                    if acc > best_acc:
                        f3 = open(args.outf + "best_acc.txt", "w")
                        f3.write("EPOCH=%d,best_acc= %.3f%%" % (epoch + 1, acc))
                        f3.close()
                        best_acc = acc
                        # torch.save(net.state_dict(), '%s/best.pth' % args.outf)
                        save_model(args.outf + '/best.pth', epoch, optimizer, best_acc, acc, net)

            print("Training Finished, TotalEPOCH=%d" % EPOCH)
